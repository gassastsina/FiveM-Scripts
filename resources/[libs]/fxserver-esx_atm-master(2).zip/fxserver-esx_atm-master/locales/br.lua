Locales['br'] = {
	['invalid_amount']    = '~r~Quantidade inválida',
	['deposit_money']          = 'Você depósitou ~g~$',
	['withdraw_money']         = 'Você retirou ~g~$', 
	['press_e_atm'] = 'Pressione ~INPUT_PICKUP~ para depósitos ou retiradas do ~g~ATM~s~.',  
}
